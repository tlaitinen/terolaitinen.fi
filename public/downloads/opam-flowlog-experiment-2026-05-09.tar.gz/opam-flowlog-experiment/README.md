# OPAM FlowLog Experiment Bundle

This bundle contains the scripts, FlowLog Datalog programs, compact result files,
and generated SVG charts used for the blog post "Incremental Datalog Conflict
Detection with OPAM Metadata".

## Contents

- `opam_datalog_experiment.py`: earlier Python-only prototype kept for comparison.
- `opam_flowlog_experiment.py`: FlowLog-based benchmark harness.
- `render_opam_flowlog_charts.py`: static SVG chart renderer.
- `programs/opam_batch.dl`: FlowLog batch Datalog program.
- `programs/opam_inc.dl`: FlowLog incremental Datalog program.
- `results/opam-flowlog-results.csv`: per-commit measurements.
- `results/opam-flowlog-results.json`: measurements plus summary and program text.
- `charts/*.svg`: generated charts embedded in the post.

Generated FlowLog binaries, generated fact CSVs, and cloned repositories are not
included. They are reproducible and too large/noisy for the bundle.

## Tooling

The recorded run used:

- FlowLog compiler: `flowlog-compiler-v0.3.0`
- FlowLog release asset:
  `https://github.com/flowlog-rs/flowlog/releases/download/flowlog-compiler-v0.3.0/flowlog-compiler-0.3.0-aarch64-apple-darwin.tar.gz`
- Python: 3.14.4
- OPAM repository: `https://github.com/ocaml/opam-repository`
- Commit window: 30 first-parent commits from
  `0d8fa4e2785bb4702bdbdbce972aecc1bbf211fb` to
  `9ed793693353d2181d75bf67c93fae35613649a4`

## Reproducing the Run

Clone OPAM repository:

```bash
git clone --depth=80 https://github.com/ocaml/opam-repository.git /tmp/opam-repository
```

Run the FlowLog benchmark:

```bash
python3 opam_flowlog_experiment.py \
  --repo /tmp/opam-repository \
  --commits 30 \
  --end-ref 9ed793693353d2181d75bf67c93fae35613649a4 \
  --output-dir /tmp/opam-flowlog \
  --workers 1
```

Regenerate charts:

```bash
python3 render_opam_flowlog_charts.py \
  --csv /tmp/opam-flowlog/opam-flowlog-results.csv \
  --output-dir /tmp/opam-flowlog/charts
```

The harness validates every incremental `Violation` snapshot against FlowLog
batch output for the same commit. It raises an exception if the relations differ.

## Model Caveats

The benchmark uses one abstract environment. It does not evaluate OPAM
`available` or `depexts` filters. Version formulas are approximated by quoted
version atoms. It measures maintained local conflict detection, not full OPAM
solver installability.
